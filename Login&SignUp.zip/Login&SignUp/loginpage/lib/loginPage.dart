import 'package:flutter/material.dart';
import './mainPage.dart';

void main() {
  runApp(
    MaterialApp(
      title: "Login Page ",
      debugShowCheckedModeBanner: false,
      // routes: {"sign-up": (context) => SignUp()},
      home: SignUp(),
    ),
  );
}
